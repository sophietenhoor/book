import type { Options } from './options';
export declare function stripPrompts({ selector, stripPrompts: prompts }: Options): void;
export declare function stripOutputPrompts({ selector, stripOutputPrompts: prompts }: Options): void;
export declare function randomId(): string;
