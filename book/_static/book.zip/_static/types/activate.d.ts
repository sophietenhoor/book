import type { Options } from './options';
export declare class ActivateWidget {
    options: Partial<Options>;
    constructor(options?: Options);
    mount(): void;
}
