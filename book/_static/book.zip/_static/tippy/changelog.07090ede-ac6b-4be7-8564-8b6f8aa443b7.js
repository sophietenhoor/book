selector_to_html = {"a[href=\"#changelog\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Changelog<a class=\"headerlink\" href=\"#changelog\" title=\"Link to this heading\">#</a></h1><p>This changelog will include all changes, except for minor adjustments like typos.</p>", "a[href=\"lecture1/displacement.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Recap displacement method<a class=\"headerlink\" href=\"#recap-displacement-method\" title=\"Link to this heading\">#</a></h1><p>In the previous <a class=\"reference internal\" href=\"lecture1/recap.html\"><span class=\"std std-doc\">chapter</span></a> you\u2019ve seen how solving for integration constants because a labour-intensive process for more complicated structures. A way of circumventing that is solving for nodal displacements! You might have seen that before when solving statically indeterminate structures using the displacement method!</p>", "a[href=\"lecture1.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Lecture 1<a class=\"headerlink\" href=\"#lecture-1\" title=\"Link to this heading\">#</a></h1><p>During today\u2019s lesson we\u2019ll get started with the basics of the matrix method: you will be introduced to the Matrix Method for solving combinations of 1D elements in statics. You\u2019ll review how we solved single- and multiple-field problems in statics during Q2, and how you might have solved statically indeterminate structures using the displacement method. We\u2019ll see how that procedure can be streamlined and optimized for computer code. Following you\u2019ll be presented the basic concepts of the Matrix Method: Obtaining element stiffness matrices, local-global transformations, assembly and postprocessing. The lecture will be finalized by arriving at an abstraction of the Matrix Method that makes it readily implementable in computer code with the help of Object Oriented Programming (OOP).</p><p>This lecture is given by Tom van Woudenberg.</p>", "a[href=\"#v2025-0-1-2025-02-10-15-02-before-first-lecture\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">v2025.0.1, 2025-02-10 15:02, before first lecture<a class=\"headerlink\" href=\"#v2025-0-1-2025-02-10-15-02-before-first-lecture\" title=\"Link to this heading\">#</a></h2>", "a[href=\"#v2025-0-0-start-course\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">v2025.0.0, start course<a class=\"headerlink\" href=\"#v2025-0-0-start-course\" title=\"Link to this heading\">#</a></h2>", "a[href=\"assignment.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Graded assignment<a class=\"headerlink\" href=\"#graded-assignment\" title=\"Link to this heading\">#</a></h1><p>When you\u2019ve finished the workshops, you can start with the graded assignment. The process is very similar to the workshops, but now there\u2019s a deadline and you\u2019re required to write a report. You\u2019re going to solve the following model for displacements and internal forces using the Matrix Method.</p>", "a[href=\"additional.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Additional assignments<a class=\"headerlink\" href=\"#additional-assignments\" title=\"Link to this heading\">#</a></h1><p>Additional assignments are provided to extend your implementation of the matrix method and apply it to other structures.</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
