selector_to_html = {"a[href=\"#lecture-1\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Lecture 1<a class=\"headerlink\" href=\"#lecture-1\" title=\"Link to this heading\">#</a></h1><p>During today\u2019s lesson we\u2019ll get started with the basics of the matrix method: you will be introduced to the Matrix Method for solving combinations of 1D elements in statics. You\u2019ll review how we solved single- and multiple-field problems in statics during Q2, and how you might have solved statically indeterminate structures using the displacement method. We\u2019ll see how that procedure can be streamlined and optimized for computer code. Following you\u2019ll be presented the basic concepts of the Matrix Method: Obtaining element stiffness matrices, local-global transformations, assembly and postprocessing. The lecture will be finalized by arriving at an abstraction of the Matrix Method that makes it readily implementable in computer code with the help of Object Oriented Programming (OOP).</p><p>This lecture is given by Tom van Woudenberg.</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
