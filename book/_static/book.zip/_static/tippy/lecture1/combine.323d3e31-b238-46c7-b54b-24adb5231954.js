selector_to_html = {"a[href=\"#combine-elements\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Combine elements<a class=\"headerlink\" href=\"#combine-elements\" title=\"Link to this heading\">#</a></h1><p>In the previous <a class=\"reference internal\" href=\"single_element.html\"><span class=\"std std-doc\">chapter</span></a> you\u2019ve seen how to set up the force-displacement relations for a single element. However, to solve for complete structures you\u2019ll need to combine multiple elements.</p>", "a[href=\"#assembly5\"]": "<figure class=\"align-center\" id=\"assembly5\">\n<img alt=\"../_images/assembly5.svg\" src=\"../_images/assembly5.svg\"/>\n<figcaption>\n<p><span class=\"caption-number\">Fig. 7 </span><span class=\"caption-text\">Extension bar with nodal load</span><a class=\"headerlink\" href=\"#assembly5\" title=\"Link to this image\">#</a></p>\n</figcaption>\n</figure>", "a[href=\"#nodaleq2\"]": "<figure class=\"align-center\" id=\"nodaleq2\">\n<img alt=\"../_images/nodaleq2.svg\" src=\"../_images/nodaleq2.svg\"/>\n<figcaption>\n<p><span class=\"caption-number\">Fig. 8 </span><span class=\"caption-text\">Free body diagrams of nodes and elements</span><a class=\"headerlink\" href=\"#nodaleq2\" title=\"Link to this image\">#</a></p>\n</figcaption>\n</figure>", "a[href=\"single_element.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Force-displacement relations single extension element<a class=\"headerlink\" href=\"#force-displacement-relations-single-extension-element\" title=\"Link to this heading\">#</a></h1><p>In the previous <a class=\"reference internal\" href=\"displacement.html\"><span class=\"std std-doc\">chapter</span></a> you\u2019ve seen how you can solve structure using nodal displacements. However, the approach was still very problem-dependent. As proposed, the matrix method solves this by defining a default element which can be solved for a priori.</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
