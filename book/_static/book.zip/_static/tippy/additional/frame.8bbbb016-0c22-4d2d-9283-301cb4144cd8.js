selector_to_html = {"a[href=\"#frame\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Frame<a class=\"headerlink\" href=\"#frame\" title=\"Link to this heading\">#</a></h1><p>Given is the following beam <span id=\"id1\">[<a class=\"reference internal\" href=\"../references.html#id6\" title=\"Hans Welleman from Delft University of Technology. Cm5 (cie4190) - contents of lectures - lecture material - part 5: matrix method. https://icozct.tudelft.nl/TUD_CT/CM5/collegestof/, 2022.\">HansWfDUoTechnology22</a>]</span>:</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
