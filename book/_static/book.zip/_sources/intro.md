# Home

Welcome to the submodule on the Matrix Method for Statics, part of Unit 2 of CIEM5000 Course base Structural Engineering at Delft University of Technology.

This TeachBook contains the material for the course.
