# Contact information 💬

This submodule is taught by Tom van Woudenberg and Iuri Rocha. Please contact us if you've any questions, feedback or when you've personal circumstances which we should know.

```{figure} figures/Tom.jpg
:width: 200px
:align: right
:class: dark-light
```
## Tom van Woudenberg
- Room 6.45
- 015-2789739
- T.R.vanWoudenberg@tudelft.nl

```{figure} figures/Iuri.png
:width: 200px
:align: right
:class: dark-light
```
## Iuri Rocha
- Room 6.40
- 015-2781458
- I.Rocha@tudelft.nl